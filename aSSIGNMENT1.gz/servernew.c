#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
int processdata(char inputstr[]) /*Function to seperate Search String and Search Key and Count the Occurence of searchkey in searchstring*/
{
	//printf("%s\n",inputstr );
	const char s[2] = ";";
	char *token,*searchkey,*searchstr;
	token = strtok(inputstr, s);
    searchstr=token;
    int counter=0;
    char *process;
    token = strtok(NULL, s);
    searchkey=token;
printf("%s:%i\n",searchkey,strlen(searchkey));    
searchkey[strlen(searchkey)-1]='\0';
	printf("%s:%s\n",searchstr,searchkey );
    const char *tmp = searchstr;
    printf("%s\n",tmp);
    while(tmp = strstr(tmp, searchkey))
	{
   	counter++;
   	printf("%s\n",tmp);
   	tmp++;
	
	}
	printf("%i\n",counter);
	return(counter);
   
   
}
		
int main(int argc, char *argv[])
{
	int			sockfd, newsockfd ; 
	int			clilen;
	struct sockaddr_in	cli_addr, serv_addr;
	int portno;
	int i;
	char message[100];		
	portno = atoi(argv[1]);
	
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("Cannot create socket\n");
		exit(0);
	}

	
	serv_addr.sin_family		= AF_INET;
	serv_addr.sin_addr.s_addr	= INADDR_ANY;
	serv_addr.sin_port = htons(portno);

	
	if (bind(sockfd, (struct sockaddr *) &serv_addr,
					sizeof(serv_addr)) < 0) {
		printf("Unable to bind local address\n");
		exit(0);
	}

	listen(sockfd, 5); 

	
	while (1) {

		
		clilen = sizeof(cli_addr);
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr,
					&clilen) ;

		if (newsockfd < 0) {
			printf("Accept error\n");
			exit(0);
		}

		int gid=fork();
		if (gid == 0) {

			
			close(sockfd);	
			bzero(message,100);
			//recv(newsockfd, message, 100, 0);
			read(newsockfd,message,100);
			//printf("%s\n", message);
			int retval=processdata(message);
			char rt[10];			
			//char *rt=(char*)retval;
			sprintf(rt,"%d",retval);			
			strcpy(message,"Message from server");
			//send(newsockfd, rt, strlen(rt) + 1, 0);
			write(newsockfd,rt,strlen(rt));
			close(newsockfd);
			exit(0);
		}

		close(newsockfd);
	}
}
			

