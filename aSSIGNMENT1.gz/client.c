#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 

void error(const char *msg)
{
    perror(msg);
    exit(0);
}
int checkstrings(char  str[],char key[])
{
	//printf("%s\n","This is Check Function" );
	
	int lenstr=strlen(str);
	int lenkey=strlen(key);
	// printf("%i\n", lenstr);
	// printf("%i\n", lenkey);
	if (lenstr>31||lenkey>6)
	{
		printf("%s\n","Error:Input exceeding length" );
		return -1;
	}
	
	if (lenstr<1||lenkey<2)
	{
		printf("%s\n","Error:Empty Input");
		return -2;	
	}
	const char c=str[lenstr-1];
	if (c!=';')
	{
		printf("%s\n","Error:Input Syntax Incorrect");
		return -3;	
	}

	


	
}
int main(int argc, char *argv[])
{
    int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    char buffer[256];
    if (argc < 3) {
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }
    printf("Please enter the Search String: ");
    char searchstr[31],searchkey[31];
    bzero(searchstr,31);
    fflush(stdin);
    //fgets(searchstr,30,stdin);
    fflush(stdin);
    scanf ("%[^\n]%*c", searchstr);
    printf("%s\n",searchstr );
    printf("Please enter the Search Key: ");
    fflush(stdin);
    bzero(searchkey,31);
    
    fgets(searchkey,30,stdin);
    //scanf("%s", searchkey);
    //scanf ("%[^\n]%*c", searchkey);
    printf("%s\n",searchkey );
    //bzero(buffer,256);
    //fgets(buffer,255,stdin);
    char *outstr;
	//searchstr[strlen(searchstr)-1]='\0';
	
    int checkval=checkstrings(searchstr,searchkey);
    if(checkval<0)
    {
    	printf("%s\n","Error in Input...Exiting" );
    	return 0;
    }

    portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);
    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting");
    

    outstr = (char *)malloc((strlen(searchstr)+strlen(searchkey)+1) * sizeof(char));
    strcpy(outstr,searchstr);
    strcat(outstr,searchkey);
    printf("%s\n",outstr);

    n = write(sockfd,outstr,strlen(outstr));
    if (n < 0) 
         error("ERROR writing to socket");
    bzero(buffer,256);
    //n = recv(sockfd, buffer, 255, 0);
    n=read(sockfd,buffer,255);
    if (n < 0) 
         error("ERROR reading from socket");
    printf("%s\n",buffer);
    close(sockfd);
    return 0;
}
